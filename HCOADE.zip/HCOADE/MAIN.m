%_________________________________________________________________________%
%  Enhanced Crayfish Optimization Algorithm with Differential Evolution(s(HCOADE)                                              %
%                                                                         %
%  Developed in MATLAB R2023a                                             %
%                                                                         %
%  Designed and Developed: BINANDA MAITI AND SAPTADEEP BISWAS             %
%                                                                         %
%         E-Mail: MATHEMATICSBINANDA@GMAIL.COM                            %
%                 saptadeepb1994@gmail.com                                %
%                                                                         %
%                                                                         %
%                                                                         %
%  .                                                                      %
%          A novel algorithm for global optimization:                     %
%   Enhanced Crayfish Optimization Algorithm with Differential Evolution                                         %
%                                                                         %
%                                                                         %
%_________________________________________________________________________%
clear all 
close all
clc

N=100;  %Number of search agents
F='F1';     %Name of the test function
T=200;           %Maximum number of iterations

    
[LB,UB,Dim,F_obj] = Get_F(F); %Get details of the benchmark functions

[best_fun1,best_position1,cuve_f1,global_Cov1]  =HCOA(N,T,LB,UB,Dim,F_obj);


figure('Position',[454   445   694   297]);
subplot(1,3,1);
func_plot(F);     % Function plot
title('Parameter space')
xlabel('x_1');
ylabel('x_2');
zlabel([F,'( x_1 , x_2 )'])
subplot(1,3,2);       % Convergence plot
semilogy(cuve_f1,'LineWidth',3)
subplot(1,3,3);       % Convergence plot
semilogy(global_Cov1,'LineWidth',3)
xlabel('Iteration#');
ylabel('Best fitness so far');
legend('COA');



display(['The best-obtained solution by HCOA is : ', num2str(best_position1)]);  
display(['The best optimal value of the objective funciton found by HCOA is : ', num2str(best_fun1)]);  