%_________________________________________________________________________%
%  Enhanced Crayfish Optimization Algorithm with Differential Evolutions(HCOADE)                                              %
%                                                                         %
%  Developed in MATLAB R2023a                                             %
%                                                                         %
%  Designed and Developed: BINANDA MAITI AND SAPTADEEP BISWAS             %
%                                                                         %
%         E-Mail: MATHEMATICSBINANDA@GMAIL.COM                            %
%                 saptadeepbiswas7@gmail.com                                %
%                                                                         %
%                                                                         %
%                                                                         %
%  .                                                                      %
%         A novel algorithm for global optimization:                     %
%   Enhanced Crayfish Optimization Algorithm with Differential Evolution                                         %
%                                                                         %
%                                                                         %
%_________________________________________________________________________%
%__________________________________________
% F_obj = @YourCostFunction
% Dim = number of your variables
% T = maximum number of iterations
% N = number of search agents
% LB=[LB1,LB2,...,LBn] where LBn is the lower bound of variable n
% UB=[UB1,UB2,...,UBn] where UBn is the upper bound of variable n
% If all the variables have equal lower bound you can just
% define LB and UB as two single numbers
function [best_fun1,best_position1,cuve_f1,global_Cov1]  =HCOA(N,T,LB,UB,Dim,F_obj)
%% Define Parameters
display('HCOADE  working');
cuve_f1=zeros(1,T); 
X=initialization(N,Dim,UB,LB); %Initialize population
global_Cov1 = zeros(1,T);
Best_fitness = inf;
best_position1 = zeros(1,Dim);
fitness_f = zeros(1,N);

for i=1:N
   fitness_f(i) =  F_obj(X(i,:)); %Calculate the fitness value of the function
   if fitness_f(i)<Best_fitness
       Best_fitness = fitness_f(i);
       best_position1 = X(i,:);
   end
end
global_position = best_position1; 
global_fitness = Best_fitness;
cuve_f1(1)=Best_fitness;
t=1; 
while(t<=T)
    C = 2-(t/T); %Eq.(7)
    temp = rand*15+20; %Eq.(3)
    xf = (best_position1+global_position)/2; % Eq.(5)
    Xfood = best_position1;
    for i=1:Dim
        beta_min=0.2;   % Lower Bound of Scaling Factor
        beta_max=0.8;   % Upper Bound of Scaling Factor
        pCR=0.2;        % Crossover Probability
        A = randperm(N);
           A(A == i) = [];
            a = A(1); b = A(2); c = A(3);
            beta = rand.*(beta_max - beta_min) + beta_min;
            y = X(a,:) + beta.* (X(b,:) -X(c,:));
%             y = max(y, LB');
%             y = min(y, UB');
            Z = zeros(size(X(i,:)));
            j0 = randi([1 Dim]);
            for j = 1:Dim
                if j == j0 || rand <= pCR
                   Z(j) = y(j);
                else
                    Z(j) = X(i,j);
                end
                
            end
           
    end
    X(i,:)=Z; 
    for i = 1:N
        
        if temp>30
            %% summer resort stage
            if rand<0.5
                Xnew(i,:) = X(i,:)+C*rand.*(xf-X(i,:)); %Eq.(6)
            else
            %% competition stage
                for j = 1:Dim
                    z = round(rand*(N-1))+1;  %Eq.(9)
                    Xnew(i,j) = X(i,j)-X(z,j)+xf(j);  %Eq.(8)
                end
            end
        else
            %% foraging stage
            P = 3*rand*fitness_f(i)/F_obj(Xfood); %Eq.(4)
            if P>2   % The food is too big
                 Xfood = exp(-1/P).*Xfood;   %Eq.(12)
                for j = 1:Dim
                    Xnew(i,j) = X(i,j)+cos(2*pi*rand)*Xfood(j)*p_obj(temp)-sin(2*pi*rand)*Xfood(j)*p_obj(temp); %Eq.(13)
                end
            else
                Xnew(i,:) = (X(i,:)-Xfood)*p_obj(temp)+p_obj(temp).*rand.*X(i,:); %Eq.(14)
            end
        end
    end
    %% boundary conditions
    for i=1:N
        for j =1:Dim
            if length(UB)==1
                Xnew(i,j) = min(UB,Xnew(i,j));
                Xnew(i,j) = max(LB,Xnew(i,j));
            else
                Xnew(i,j) = min(UB(j),Xnew(i,j));
                Xnew(i,j) = max(LB(j),Xnew(i,j));
            end
        end
    end
   
    global_position = Xnew(1,:);
    global_fitness = F_obj(global_position);
 
    for i =1:N
         %% Obtain the optimal solution for the updated population
        new_fitness = F_obj(Xnew(i,:));
        if new_fitness<global_fitness
                 global_fitness = new_fitness;
                 global_position = Xnew(i,:);
        end
        %% Update the population to a new location
        if new_fitness<fitness_f(i)
             fitness_f(i) = new_fitness;
             X(i,:) = Xnew(i,:);
             if fitness_f(i)<Best_fitness
                 Best_fitness=fitness_f(i);
                 best_position1 = X(i,:);
             end
        end
    end
    global_Cov1(t) = global_fitness;
    cuve_f1(t) = Best_fitness;
    t=t+1;
    if mod(t,100)==0
      disp("COA"+"iter"+num2str(t)+": "+Best_fitness); 
   end
end
 best_fun1 = Best_fitness;
end
function y = p_obj(x)   %Eq.(4)
    y = 0.2*(1/(sqrt(2*pi)*3))*exp(-(x-25).^2/(2*3.^2));
end